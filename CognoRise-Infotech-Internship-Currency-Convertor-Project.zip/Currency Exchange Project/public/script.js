document.addEventListener('DOMContentLoaded', () => {
    const apiUrl = 'https://v6.exchangerate-api.com/v6/354b08922e821cbe8185d120/latest/';
    const fromCurrency = document.getElementById('from-currency');
    const toCurrency = document.getElementById('to-currency');
    const alertCurrency = document.getElementById('alert-currency'); // Select element for alerts
    const amount = document.getElementById('amount');
    const resultDiv = document.getElementById('result');
    const converterForm = document.getElementById('converter-form');
    const loadingIndicator = document.getElementById('loading');
    const newsApiKey = '9172985da1f34b93820f7a6bfe0c329d';
    const newsApiUrl = 'https://newsapi.org/v2/everything?q=currency&sortBy=publishedAt';
    const newsArticlesContainer = document.getElementById('news-articles');
    const darkModeSwitch = document.getElementById('dark-mode-switch');
    const alertForm = document.getElementById('alert-form');
    const notification = document.getElementById('notification');
    const notificationMessage = document.getElementById('notification-message');

    // Fetch currencies for dropdowns
    fetch('https://v6.exchangerate-api.com/v6/354b08922e821cbe8185d120/codes')
        .then(response => response.json())
        .then(data => {
            data.supported_codes.forEach(code => {
                const option = document.createElement('option');
                option.value = code[0];
                option.textContent = `${code[0]} - ${code[1]}`;
                fromCurrency.appendChild(option.cloneNode(true));
                toCurrency.appendChild(option.cloneNode(true));
                alertCurrency.appendChild(option.cloneNode(true)); // Populate alert currency options
            });
        });

    // Dark mode toggle
    darkModeSwitch.addEventListener('click', () => {
        document.body.classList.toggle('dark');
    });

    // Currency conversion form submit
    converterForm.addEventListener('submit', event => {
        event.preventDefault();
        convertCurrency();
    });

    function convertCurrency() {
        const from = fromCurrency.value;
        const to = toCurrency.value;
        const amountValue = amount.value;

        if (!from || !to || !amountValue) {
            resultDiv.textContent = 'Please fill in all fields.';
            return;
        }

        loadingIndicator.classList.remove('hidden');
        resultDiv.textContent = '';

        fetch(`${apiUrl}${from}`)
            .then(response => response.json())
            .then(data => {
                const exchangeRate = data.conversion_rates[to];
                const convertedAmount = (amountValue * exchangeRate).toFixed(2);
                resultDiv.textContent = `${amountValue} ${from} = ${convertedAmount} ${to}`;
                loadingIndicator.classList.add('hidden');
            })
            .catch(error => {
                console.error('Error converting currency:', error);
                resultDiv.textContent = 'Error converting currency.';
                loadingIndicator.classList.add('hidden');
            });
    }

    // Alert form submit
    alertForm.addEventListener('submit', event => {
        event.preventDefault();
        addAlert();
    });

    function addAlert() {
        const alertCurrencyValue = document.getElementById('alert-currency').value;
        const alertRateValue = document.getElementById('alert-rate').value;

        if (!alertCurrencyValue || !alertRateValue) {
            alert('Please fill in all fields for the alert.');
            return;
        }

        // Add your alert handling logic here
        // For demonstration, we'll show a success message
        showNotification(`Alert set for ${alertCurrencyValue} at rate ${alertRateValue}`);
    }

    // Show custom notification
    function showNotification(message) {
        notificationMessage.textContent = message;
        notification.classList.add('show');
        setTimeout(() => {
            notification.classList.remove('show');
        }, 3000); // Hide after 3 seconds
    }

    // Close notification
    window.closeNotification = function() {
        notification.classList.remove('show');
    };

    // Fetch news articles
    fetch(newsApiUrl, {
        method: 'GET',
        headers: {
            'X-Api-Key': newsApiKey
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return response.json();
    })
    .then(data => {
        if (data.articles && data.articles.length) {
            data.articles.forEach(article => {
                const articleDiv = document.createElement('div');
                articleDiv.classList.add('news-article');

                const title = document.createElement('h3');
                title.textContent = article.title;
                articleDiv.appendChild(title);

                const description = document.createElement('p');
                description.textContent = article.description;
                articleDiv.appendChild(description);

                const link = document.createElement('a');
                link.href = article.url;
                link.textContent = 'Read more';
                link.target = '_blank';
                articleDiv.appendChild(link);

                newsArticlesContainer.appendChild(articleDiv);
            });
        } else {
            newsArticlesContainer.textContent = 'No news articles found.';
        }
    })
    .catch(error => {
        console.error('Error fetching news articles:', error);
        newsArticlesContainer.textContent = 'Failed to load news articles.';
    });
});
