const express = require('express');
const cors = require('cors');
const path = require('path');
const fetch = require('node-fetch');

const app = express();
const PORT = process.env.PORT || 3000;
const FIXER_API_KEY = '7b2938ad7b88bf6b4c158829c888e57a'; // Updated Fixer API key

// Enable CORS for all routes
app.use(cors());

// Serve static files from the public directory
app.use(express.static(path.join(__dirname, 'public')));

// Route for the root URL
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Route to get historical exchange rates
app.get('/historical-rates', async (req, res) => {
    const { start, end, from, to } = req.query;

    try {
        const startDate = new Date(start).toISOString().split('T')[0];
        const endDate = new Date(end).toISOString().split('T')[0];

        // Fetch historical rates for each day in the range
        const requests = [];
        let currentDate = new Date(startDate);

        while (currentDate <= new Date(endDate)) {
            const dateStr = currentDate.toISOString().split('T')[0];
            requests.push(fetch(`https://data.fixer.io/api/${dateStr}?base=${from}&symbols=${to}&access_key=${FIXER_API_KEY}`));
            currentDate.setDate(currentDate.getDate() + 1);
        }

        const responses = await Promise.all(requests);
        const data = await Promise.all(responses.map(res => res.json()));

        // Process data
        const result = data.reduce((acc, dayData) => {
            if (dayData && dayData.rates && dayData.rates[to]) {
                acc[dayData.date] = dayData.rates[to];
            }
            return acc;
        }, {});

        res.json(result);
    } catch (error) {
        console.error('Error fetching historical rates:', error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
